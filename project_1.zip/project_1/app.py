import streamlit as st
import google.generativeai as genai
from dotenv import load_dotenv
import os
from PIL import Image

load_dotenv()  # Load environment variables

my_api_key = os.getenv("GOOGLE_API_KEY")  # Getting API key from environment variables
genai.configure(api_key=my_api_key)

def process_image_aadhaar(image):
    model = genai.GenerativeModel('gemini-1.5-pro')
    response = model.generate_content(["""Analyze the provided image and extract the following information:
                                        - Full Name
                                        - Date of Birth
                                        - Aadhar Number
                                        - Gender

                                        Present the extracted information in the following format:

                                        name: ...
                                        date_of_birth: ...
                                        aadhaar_number: ...
                                        gender: ...

                                        Important:
                                        1. Do not include any quotation marks, asterisks (*), underscores (_), backslashes (\), or forward slashes (/) in the output.
                                        2. Remove any of these characters if they appear in the extracted data.
                                        3. If any information is not visible or cannot be extracted from the image, replace it with N/A in the output.
                                        4. Maintain the exact order of fields as shown above.
                                        5. Include only the extracted values after each field name, without any additional punctuation.
                                        6. Ensure there is a space after each colon (:) and before the extracted value.""", image])
    extracted_info = response.text.split("\n")
    
    info_dict = {}  # {"name": Shivan}
    for line in extracted_info: # aadhar number: aadhar_number
        if ":" in line:
            key, value = line.split(":", 1)

            info_dict[key.strip().replace(" ", "_")] = value.strip()
    return info_dict

st.title("Aadhaar Card Information Extractor")

uploaded_file = st.file_uploader("Choose an Aadhaar card image", type=["jpg", "jpeg", "png"])

if uploaded_file is not None:
    image = Image.open(uploaded_file)
    st.image(image, caption="Uploaded Aadhaar Card Image", use_column_width=True)
    
    if st.button("Extract Information"):
        with st.spinner("Processing image..."):
            extracted_info = process_image_aadhaar(image)
        
        st.subheader("Extracted Information:")
        for key, value in extracted_info.items():
            st.write(f"{key.replace('_', ' ').title()}: {value}")